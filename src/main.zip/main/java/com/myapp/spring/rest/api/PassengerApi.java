package com.myapp.spring.rest.api;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.myapp.spring.model.Product;
import com.myapp.spring.repository.PassengerRepository;

@RestController
@RequestMapping("/passenger")

public class PassengerApi {

	@Autowired

	private PassengerRepository repository;
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@PostMapping("/loyalty_points/")
	public Product saveNewProduct(@RequestBody Product product) {

		return repository.saveProduct(product);

	}

	@PutMapping("/{id}")
	public Product updateProduct(@PathVariable("id") Integer productid, @RequestBody Product product) {

		Product existingProduct = repository.findById(productid);
		BeanUtils.copyProperties(product, existingProduct);
		return repository.updateProduct(product);
	}

	@GetMapping("/{id}")
	public Product findById(@PathVariable("id") Integer productid) {

		// Product existingProduct =repository.findById(productid);

		return repository.findById(productid);
	}

//	@GetMapping("loyalty_points/{name}")
//	public void getAll(@PathVariable("name") String name) {
//		String query = "select loyalty_points from loyalty_points where passenger_name=?";
//		Object[] inputs = new Object[] { name };
//		Integer lp = jdbcTemplate.queryForObject(query, Integer.class, inputs);
//		jdbcTemplate.update("insert into loyalty_points(loyalty_points) values (?)", lp + 5);
//
//	}
//	@GetMapping("loyalty_points/{name}")
//	public Product getAll(@PathVariable("name") String product) {
//		List<Product> a = repository.findAll(product);
//		int num = a.size();
////		return "<html><body>" + "<h1>Here's Your Loyalty Points details " + product
////				+ "</h1><br> <h3>As you have travelled with our airlines " + num
////				+ " times.you have total loyalty points of  " + num * 5 + "</h3>" + "</body></html>";
//		
//	}

}